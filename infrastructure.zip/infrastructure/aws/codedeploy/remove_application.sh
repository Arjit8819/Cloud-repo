
#!/bin/bash
rm -rf /home/centos/WebApp/*

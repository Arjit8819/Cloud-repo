# CSYE 6225 - Spring 2019

## Team Information

| Name | NEU ID | Email Address |
| --- | --- | --- |
|Ritu Agrawal| 001814874| agrawal.ritu@husky.neu.edu|
|Arjit Kiledar| 001846796| kiledar.a@husky.neu.edu|
|Shantanu Deosthale| 001851612| deosthale.s@husky.neu.edu|
|Amish Garhwal| 001860961| garhwal.a@husky.neu.edu|

## Technology Stack
OS- Ubuntu 18.04(Linux)
Programming Language - C# 
Relational Database- MYSQL
Backend FrameWork - ASP.NET Core 2.2

## Build Instructions
First run setup.sh using bash and provide details
then run delete to delete.

## Deploy Instructions


## Running Tests


## CI/CD


